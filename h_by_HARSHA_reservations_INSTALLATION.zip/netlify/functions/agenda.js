"use strict";
const {DateTime}=require('luxon');
const {getPool}=require('../../lib/db');
const {TZ,validDate,clean,response}=require('../../lib/config');
const {publicCity}=require('../../lib/geo');

// No names, street addresses, stable names, prices, or phone numbers on this endpoint.
exports.handler=async event=>{
 if(event.httpMethod!=='GET')return response(405,{error:'Méthode non autorisée.'});
 const from=clean(event.queryStringParameters?.from,10),to=clean(event.queryStringParameters?.to,10);
 if(!validDate(from)||!validDate(to))return response(400,{error:'Période incorrecte.'});
 const start=DateTime.fromISO(from,{zone:TZ}),end=DateTime.fromISO(to,{zone:TZ});
 if(end<=start||end.diff(start,'days').days>45||start<DateTime.now().setZone(TZ).startOf('day').minus({days:8})||end>DateTime.now().setZone(TZ).plus({months:7}))return response(400,{error:'Période indisponible.'});
 if(!process.env.DATABASE_URL)return response(503,{error:'Agenda indisponible.'});
 try{
  const r=await getPool().query(`SELECT start_at,public_city FROM public.hbh_bookings
    WHERE type='booking' AND status='confirmed' AND start_at >= $1 AND start_at < $2
    AND public_city IS NOT NULL ORDER BY start_at LIMIT 300`,[start.toUTC().toISO(),end.toUTC().toISO()]);
  return response(200,{visits:r.rows.flatMap(x=>{
   const city=publicCity(x.public_city);if(!city)return [];
   const time=DateTime.fromJSDate(x.start_at).setZone(TZ);
   return [{day:time.toFormat('yyyy-MM-dd'),time:time.toFormat('HH:mm'),city}];
  })});
 }catch(e){console.error('Public agenda',e);return response(503,{error:'Déplacements indisponibles.'})}
};
