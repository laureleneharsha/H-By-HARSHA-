'use strict';
const {randomUUID}=require('node:crypto');
const {DateTime}=require('luxon');
const {getPool,listDay,getBase}=require('../../lib/db');
const {TZ,SERVICES,PARTNERS,NOTICE_HOURS,HOLD_HOURS,priceFor,allowedDate,durationFor,clean,response}=require('../../lib/config');
const {geocode}=require('../../lib/geo');
const {slotsForDay,checkSlot}=require('../../lib/slots');
const {sendMail}=require('../../lib/email');
exports.handler=async event=>{
 if(event.httpMethod!=='POST')return response(405,{error:'Méthode non autorisée.'});
 let p;try{p=JSON.parse(event.body||'{}')}catch{return response(400,{error:'Données invalides.'})}
 const action=clean(p.action,25);
 if(!['slots','reserve'].includes(action))return response(400,{error:'Action inconnue.'});
 if(!process.env.DATABASE_URL)return response(503,{error:'Agenda en cours de mise en service. Aucun faux créneau ne sera proposé.'});
 const date=clean(p.date,10),serviceId=clean(p.service,40),address=clean(p.address,280);
 if(!allowedDate(date))return response(400,{error:'Jour indisponible. Réservations possibles à partir de janvier 2027, dans les six mois à venir.'});
 const service=SERVICES[serviceId];if(!service)return response(400,{error:'Sélectionnez une prestation.'});
 const horses=Number(p.horses??1),boxes=Number(p.boxes??0),paddocks=Number(p.paddocks??0);
 const duration=durationFor(serviceId,{horses,boxes,paddocks});
 if(!duration)return response(422,{error:'Quantité non valide ou prestation trop longue pour une journée.'});
 if(address.length<8)return response(422,{error:'Renseignez une adresse complète (rue, code postal et commune).'});
 if(p.website)return response(400,{error:'Données invalides.'});
 let loc;try{loc=await geocode(address)}catch(e){return response(422,{error:e.message})}
 let db;try{db=getPool()}catch(e){return response(503,{error:'Agenda indisponible actuellement.'})}
 if(action==='slots'){
  try{const [bookings,base]=await Promise.all([listDay(db,date),getBase(db)]);
   const slots=await slotsForDay({day:date,duration,loc,bookings,base});
   return response(200,{date,service:serviceId,duration,slots,addressFound:loc.label,refreshedAt:DateTime.now().setZone(TZ).toISO(),timezone:TZ});
  }catch(e){console.error('Slots',e);const safeCodes=['SELF_SIGNED_CERT_IN_CHAIN','UNABLE_TO_VERIFY_LEAF_SIGNATURE','CERT_HAS_EXPIRED','ENOTFOUND','ETIMEDOUT','28P01','3D000','ECONNREFUSED','42P01','42703'];const diagnostic=safeCodes.includes(e.code)?e.code:/Adresse précise non localisée/.test(e.message)?'BASE_GEOCODING':/Adresse de départ privée non configurée/.test(e.message)?'BASE_CONFIGURATION':'OTHER';return response(503,{diagnostic,error:'Les trajets ou les disponibilités ne peuvent pas être vérifiés. Réessayez plus tard.'})}
 }
 const name=clean(p.name,110),email=clean(p.email,170),phone=clean(p.phone,40),stable=clean(p.stable,120),note=clean(p.note,800),promo=clean(p.promo,35).toUpperCase(),partner=clean(p.partner,35).toUpperCase();
 if(!name||!stable||!phone||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return response(422,{error:'Complétez votre nom, e-mail, téléphone et nom de l’écurie.'});
 if(partner&&!PARTNERS.includes(partner))return response(422,{error:'Code partenaire non reconnu. Vérifiez votre code ou laissez le champ vide.'});
 // Un code promo n'applique aucune réduction automatique. Montant validé par l'administratrice.
 const start=DateTime.fromISO(clean(p.start,38),{setZone:true});
 if(!start.isValid||start.setZone(TZ).toFormat('yyyy-MM-dd')!==date||start.offset!==0)return response(400,{error:'Créneau incorrect. Rechargez les disponibilités.'});
 if((start.setZone(TZ).minute%30)!==0)return response(400,{error:'Ce créneau ne correspond pas à la grille horaire.'});
 const client=await db.connect();let record;
 try{
  await client.query('BEGIN');
  await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[date]);
  const [bookings,base]=await Promise.all([listDay(client,date),getBase(client)]);
  const decision=await checkSlot({day:date,startISO:start.toUTC().toISO(),duration,loc,bookings,base});
  if(!decision.ok){await client.query('ROLLBACK');return response(409,{error:'Ce créneau vient de devenir indisponible. Choisissez-en un autre.'})}
  const id=randomUUID(),end=start.plus({minutes:duration}).toUTC().toISO();
  const holdUntil=DateTime.now().plus({hours:HOLD_HOURS}).toUTC().toISO();
  await client.query(`INSERT INTO hbh_bookings(id,type,status,service_id,service_label,profile,stable,address,lat,lon,duration_min,start_at,end_at,hold_until,customer_name,customer_email,customer_phone,horses,boxes,paddocks,partner_code,promo_code,note,price_note,public_city) VALUES ($1,'booking','pending',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)`,[
   id,serviceId,service.label,service.profile,stable,loc.label,loc.lat,loc.lon,duration,start.toUTC().toISO(),end,holdUntil,name,email,phone,horses,boxes,paddocks,partner||null,promo||null,note,priceFor(serviceId,horses),loc.city
  ]);
  await client.query('COMMIT');
  record={id,name,email,phone,stable,address:loc.label,service:service.label,date,hour:start.setZone(TZ).toFormat('HH:mm'),duration,horses,boxes,paddocks,partner,promo,note,hold:start.setZone(TZ).toLocaleString(),holdUntil};
 }catch(e){try{await client.query('ROLLBACK')}catch{}console.error('Booking',e);return response(503,{error:'Votre réservation n’a pas été enregistrée. Merci de réessayer.'})}finally{client.release()}
 const mailResults=await Promise.allSettled([
  sendMail(process.env.MAIL_TO,'Nouvelle demande h by HARSHA',`Nouvelle demande en attente\n\nClient : ${name}\nE-mail : ${email}\nTéléphone : ${phone}\nPrestation : ${record.service}\nÉcurie : ${stable}\nAdresse : ${record.address}\nDate et heure : ${date} ${record.hour}\nDurée : ${duration} minutes\nBoxes : ${boxes} / Paddocks : ${paddocks}\nPartenaire : ${partner||'aucun'} / Promo : ${promo||'aucun'}\nNote : ${note}\n\nGérer : https://laureleneharsha.netlify.app/gestion/`),
  sendMail(email,'Votre demande de rendez-vous — h by HARSHA',`Bonjour ${name},\n\nMerci pour votre demande !\n\nVoici votre récapitulatif :\n${record.service}\nLe ${DateTime.fromISO(date).toFormat('dd/MM/yyyy')} à ${record.hour}\nÀ ${stable} — ${record.address}\n\nJe vérifie mes disponibilités et les déplacements, puis je vous confirme personnellement le rendez-vous. Votre demande ne vaut pas encore confirmation.\n\nUne question ? Répondez simplement à cet e-mail.\n\nÀ bientôt,\nh by HARSHA`)
 ]);
 const sent=index=>mailResults[index].status==='fulfilled'&&mailResults[index].value?.sent===true;
 return response(201,{ok:true,reference:record.id,status:'pending',emails:{owner:sent(0),customer:sent(1)},message:'Merci, votre demande est bien reçue ! Laurélène vous confirmera personnellement le rendez-vous.'});
};
