'use strict';
const {randomUUID,timingSafeEqual}=require('node:crypto');
const {DateTime}=require('luxon');
const {getPool}=require('../../lib/db');
const {response,clean,TZ,validDate,dayBounds}=require('../../lib/config');
const {sendMail}=require('../../lib/email');
const {geocode}=require('../../lib/geo');
function allowed(event){const expected=process.env.ADMIN_TOKEN;const given=(event.headers.authorization||event.headers.Authorization||'').replace(/^Bearer\s+/i,'');if(!expected||expected.length<32||!given)return false;const a=Buffer.from(given),b=Buffer.from(expected);return a.length===b.length&&timingSafeEqual(a,b)}
exports.handler=async event=>{
 if(event.httpMethod!=='POST')return response(405,{error:'Méthode non autorisée.'});
 if(!allowed(event))return response(401,{error:'Code d’accès incorrect ou non configuré.'});
 let p;try{p=JSON.parse(event.body||'{}')}catch{return response(400,{error:'Données incorrectes.'})}
 if(!process.env.DATABASE_URL)return response(503,{error:'Base de données non configurée.'});
 const db=getPool(),action=clean(p.action,30);
 try{
  if(action==='get_settings'){
   const q=await db.query('SELECT base_label,updated_at FROM hbh_settings WHERE id=1');
   return response(200,{baseLabel:q.rows[0]?.base_label||'Non configuré',updatedAt:q.rows[0]?.updated_at||null});
  }
  if(action==='set_base'){
   const address=clean(p.address,280);
   if(address.length<12)return response(422,{error:'Saisissez une adresse complète à La Biolle (rue, numéro et code postal).'});
   let location;try{location=await geocode(address)}catch(e){return response(422,{error:e.message})}
   if(!/la biolle/i.test(location.label))return response(422,{error:'L’adresse de départ doit se situer à La Biolle. Vérifiez l’adresse reconnue.'});
   await db.query(`INSERT INTO hbh_settings(id,base_label,base_lat,base_lon,updated_at)
       VALUES (1,$1,$2,$3,now()) ON CONFLICT(id) DO UPDATE
       SET base_label=EXCLUDED.base_label,base_lat=EXCLUDED.base_lat,base_lon=EXCLUDED.base_lon,updated_at=now()`,
       [location.label,location.lat,location.lon]);
   return response(200,{ok:true,baseLabel:location.label,message:'Adresse de départ privée mise à jour.'});
  }
  if(action==='list'){
   const date=clean(p.date,10);if(!validDate(date))return response(400,{error:'Date incorrecte.'});const b=dayBounds(date);
   const data=await db.query(`SELECT id,type,CASE WHEN status='pending' AND hold_until<=now() THEN 'expired' ELSE status END AS status,service_label,stable,address,duration_min,start_at,end_at,hold_until,customer_name,customer_email,customer_phone,horses,boxes,paddocks,partner_code,promo_code,note,price_note,created_at FROM hbh_bookings WHERE start_at<$2 AND end_at>$1 ORDER BY start_at`,[b.start,b.end]);
   return response(200,{items:data.rows});
  }
  if(action==='change'){
   const id=clean(p.id,40),status=clean(p.status,30);
   if(!['confirmed','refused','cancelled'].includes(status)||!/^[a-f\d-]{36}$/i.test(id))return response(400,{error:'Action incorrecte.'});
   const client=await db.connect();let row;
   try{await client.query('BEGIN');
    const q=await client.query('SELECT * FROM hbh_bookings WHERE id=$1 FOR UPDATE',[id]);row=q.rows[0];if(!row){await client.query('ROLLBACK');return response(404,{error:'Rendez-vous introuvable.'})}
    if(status==='confirmed'&&!(row.status==='pending'&&new Date(row.hold_until)>new Date())){await client.query('ROLLBACK');return response(409,{error:'La demande a expiré ou n’est plus en attente. Le client doit refaire une demande.'})}
    if(status==='refused'&&row.status!=='pending'){await client.query('ROLLBACK');return response(409,{error:'Seules les demandes en attente peuvent être refusées.'})}
    if(status==='cancelled'&&!['confirmed','pending','blocked'].includes(row.status)){await client.query('ROLLBACK');return response(409,{error:'Rendez-vous déjà terminé ou annulé.'})}
    await client.query('UPDATE hbh_bookings SET status=$1,updated_at=now() WHERE id=$2',[status,id]);
    await client.query('COMMIT');
   }catch(e){try{await client.query('ROLLBACK')}catch{}throw e}finally{client.release()}
   if(row.customer_email&&row.type==='booking')await sendMail(row.customer_email,'Votre rendez-vous h by HARSHA',`Bonjour ${row.customer_name},\n\nVotre demande du ${DateTime.fromJSDate(row.start_at).setZone(TZ).toFormat('dd/MM/yyyy à HH:mm')} pour ${row.service_label} a été ${status==='confirmed'?'CONFIRMÉE':status==='refused'?'REFUSÉE':'ANNULÉE'}.\n\n${status==='confirmed'?'À bientôt !':'Pour toute question, contactez h by HARSHA.'}\n\nh by HARSHA`).catch(e=>console.error('Email',e));
   return response(200,{ok:true,status});
  }
  if(action==='block'){
   const date=clean(p.date,10),time=clean(p.time,5),duration=Number(p.minutes),reason=clean(p.note,120)||'Indisponibilité';
   if(!validDate(date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)||!Number.isInteger(duration)||duration<30||duration>780)return response(400,{error:'Date, heure ou durée incorrectes.'});
   const start=DateTime.fromISO(`${date}T${time}`,{zone:TZ});const end=start.plus({minutes:duration});if(!start.isValid||end.toFormat('yyyy-MM-dd')!==date)return response(400,{error:'Le blocage doit rester sur une seule journée.'});
   const client=await db.connect();try{await client.query('BEGIN');await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[date]);
    const q=await client.query(`SELECT id FROM hbh_bookings WHERE (status IN ('confirmed','blocked') OR (status='pending' AND hold_until>now())) AND start_at<$2 AND end_at>$1 LIMIT 1`,[start.toUTC().toISO(),end.toUTC().toISO()]);
    if(q.rowCount){await client.query('ROLLBACK');return response(409,{error:'Cette période contient déjà un rendez-vous ou un blocage.'})}
    await client.query(`INSERT INTO hbh_bookings(id,type,status,service_label,duration_min,start_at,end_at,note) VALUES ($1,'block','blocked','Indisponible',$2,$3,$4,$5)`,[randomUUID(),duration,start.toUTC().toISO(),end.toUTC().toISO(),reason]);await client.query('COMMIT');return response(201,{ok:true});
   }catch(e){try{await client.query('ROLLBACK')}catch{}throw e}finally{client.release()}
  }
  return response(400,{error:'Action inconnue.'});
 }catch(e){console.error('Admin',e);return response(503,{error:'Service momentanément indisponible.'})}
};
