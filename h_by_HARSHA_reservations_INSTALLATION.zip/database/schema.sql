-- À exécuter dans SQL Editor Supabase après création du projet.
-- Seules les fonctions serveur accèdent à ces tables. Ne pas autoriser l'accès public.
CREATE TABLE IF NOT EXISTS hbh_bookings (
 id uuid PRIMARY KEY,
 type text NOT NULL DEFAULT 'booking' CHECK(type IN ('booking','block')),
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','refused','cancelled','blocked','expired')),
 service_id text,
 service_label text,
 profile text,
 stable text,
 address text,
 lat double precision,
 lon double precision,
 duration_min integer NOT NULL CHECK (duration_min BETWEEN 1 AND 780),
 start_at timestamptz NOT NULL,
 end_at timestamptz NOT NULL,
 hold_until timestamptz,
 customer_name text,
 customer_email text,
 customer_phone text,
 horses integer DEFAULT 1,
 boxes integer DEFAULT 0,
 paddocks integer DEFAULT 0,
 partner_code text,
 promo_code text,
 note text,
 price_note text,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT hbh_dates_valid CHECK (end_at > start_at)
);
CREATE INDEX IF NOT EXISTS hbh_bookings_time_idx ON hbh_bookings(start_at,end_at) WHERE status IN ('pending','confirmed','blocked');
CREATE INDEX IF NOT EXISTS hbh_bookings_status_idx ON hbh_bookings(status,created_at);
CREATE TABLE IF NOT EXISTS hbh_settings (
 id smallint PRIMARY KEY CHECK(id=1),
 base_label text NOT NULL,
 base_lat double precision NOT NULL,
 base_lon double precision NOT NULL,
 base_verified boolean NOT NULL DEFAULT false,
 updated_at timestamptz NOT NULL DEFAULT now()
);
-- Coordonnées initiales : CENTRE APPROXIMATIF de La Biolle, pas votre adresse privée.
INSERT INTO hbh_settings(id,base_label,base_lat,base_lon)
VALUES (1,'La Biolle (centre approximatif) - à personnaliser',45.755311,5.927449)
ON CONFLICT (id) DO NOTHING;
-- Niveaux de sécurité : pas d'accès public par API Supabase.
ALTER TABLE hbh_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE hbh_settings ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON hbh_bookings FROM anon, authenticated;
REVOKE ALL ON hbh_settings FROM anon, authenticated;
