'use strict';
(function(root){
 const KEY='hbh.admin.session.v1',DURATION=30*24*60*60*1000;
 const clear=storage=>{try{storage.removeItem(KEY)}catch{}};
 function read(storage,now=Date.now()){
  try{const value=JSON.parse(storage.getItem(KEY)||'null');
   if(!value||typeof value.token!=='string'||!value.token.trim()||!Number.isFinite(value.expiresAt)||value.expiresAt<=now||value.expiresAt>now+DURATION){clear(storage);return ''}
   return value.token;
  }catch{clear(storage);return ''}
 }
 function save(storage,token,now=Date.now()){
  try{storage.setItem(KEY,JSON.stringify({token,expiresAt:now+DURATION}));return true}catch{return false}
 }
 const session={KEY,read,save,clear};
 if(typeof module==='object'&&module.exports)module.exports=session;else root.HbhRememberSession=session;
})(typeof window==='undefined'?{}:window);
