# h by HARSHA — Réservations en ligne (version à connecter)

## Ce qui est prêt

- Site h by HARSHA (copie de référence datée du 24 octobre 2026) et bouton **Réserver en ligne**.
- Page clients `/reserver/` : calendrier mensuel/hebdomadaire, propriétaire/professionnel, boxes et paddocks conditionnels, codes partenaires et demande de créneau.
- API serveur pour calculer les créneaux à partir de 7h à 20h, 7 jours sur 7, préavis minimum 12 heures.
- 20 min par box, 20 min par paddock et marge de 10 min entre rendez-vous et trajets.
- Premier départ de La Biolle autorisé avant 7h ; dernière prestation terminée à 20h, sans obligation de retour avant cette heure.
- Itinéraire entre écuries, sans retour automatique à La Biolle à chaque rendez-vous.
- Demandes en attente bloquées 4 heures ; confirmation ou refus par l'administratrice ; protection contre deux demandes simultanées sur un même créneau.
- Espace privé `/gestion/` : calendrier, demandes à traiter, blocage d'indisponibilités et réglage de l'adresse exacte de départ (non publique).
- Codes partenaires existants : HBH-FONDA01 à HBH-FONDA05. Aucun paiement ni facturation automatique.

**IMPORTANT : LE ZIP EST UN DOSSIER D'INSTALLATION, PAS UN SITE DÉJÀ MIS EN SERVICE.**
Il ne faut PAS le déposer comme un simple site statique avec Netlify Drop : les fonctions serveur et les dépendances Node doivent être installées et déployées via Netlify Builds connecté à un dépôt Git, ou via Netlify CLI. Tant que DATABASE_URL et le schéma SQL ne sont pas connectés, la page clients ne proposera pas de faux créneaux.

## Mise en service — pas à pas

1. **Sauvegarder le site existant** : dans Netlify, conserver la version actuellement publiée. Ce projet utilise une copie du site datant du **24 octobre 2026** ; si tu as modifié le site depuis, fusionner les modifications dans `public/index.html` avant de publier pour ne pas les perdre.
2. **Créer un projet Supabase gratuit**. Ouvrir `database/schema.sql`, copier tout son contenu dans le **SQL Editor** Supabase et l'exécuter. Ne pas publier les identifiants de base de données dans des fichiers HTML.
3. Dans **Supabase > Connect**, copier le **Transaction pooler** PostgreSQL (`:6543`, idéal pour fonctions serverless) puis configurer la variable d'environnement Netlify `DATABASE_URL` avec cette adresse complète, y compris le mot de passe.
4. Dans Netlify > **Project configuration > Environment variables**, configurer `ADMIN_TOKEN` (une phrase secrète aléatoire d'au moins 32 caractères, non incluse dans le ZIP) et `PARTNER_CODES` (facultatif, défaut : `HBH-FONDA01,HBH-FONDA02,HBH-FONDA03,HBH-FONDA04,HBH-FONDA05`). Ne jamais écrire ces valeurs dans `public/` ni les communiquer aux clients.
5. **Déployer le projet complet** avec un dépôt Git connecté à Netlify (conseillé) ou Netlify CLI. Netlify doit détecter `netlify.toml`, installer les dépendances depuis `package.json` et publier `public/` + `netlify/functions/`. Un simple ZIP déposé en drag-and-drop ne suffit pas à assurer l'exécution correcte des fonctions serveur.
6. Ouvrir `https://laureleneharsha.netlify.app/gestion/`, saisir le `ADMIN_TOKEN`, puis enregistrer ton **adresse de départ privée à La Biolle**. Par défaut, la base contient seulement les coordonnées approximatives du centre de La Biolle : à remplacer AVANT l'ouverture aux clients.
7. Faire un essai de demande depuis `/reserver/`, vérifier son apparition dans `/gestion/`, accepter/refuser et confirmer que le créneau est libéré ou bloqué comme prévu.

### E-mails automatiques (une connexion supplémentaire)

Pour activer les e-mails aux clients ET les notifications de nouvelles demandes à l'administratrice, ajouter dans Netlify :

- `RESEND_API_KEY` : clé API créée sur Resend ;
- `MAIL_FROM` : adresse vérifiée autorisée par Resend, par exemple `reservations@ton-domaine.fr` ;
- `MAIL_TO` : ton adresse e-mail personnelle ou professionnelle.

**Attention :** envoyer des e-mails à tous les clients exige généralement la vérification d'un domaine que tu contrôles chez le prestataire e-mail. Un sous-domaine gratuit `netlify.app` ne t'appartient pas pour la vérification DNS. Sans ces variables, les réservations restent enregistrées mais **aucun e-mail automatique n'est garanti**. Il est déconseillé d'ouvrir les réservations au public avant de tester les notifications.

## Paramètres et tarifs

Dans `lib/config.js`, tu peux ajuster les durées estimées des prestations. Celles qui n'avaient pas de durée validée sont **indicatives** et doivent être confirmées avant publication. Les prestations sur devis affichent « Sur devis » ; pas de paiement à la réservation.

Le service de calcul d'itinéraire IGN/Géoplateforme a une limite d'utilisation (5 requêtes/s depuis une IP) ; ne jamais garantir qu'une API publique gratuite sera toujours disponible. En cas d'échec, le système ne propose pas de créneau non vérifié.

## Vie privée

Le calcul des itinéraires utilise la véritable adresse de départ seulement côté serveur. Les clients ne voient que « La Biolle » ; ne jamais la copier dans une page publique. Les noms, numéros et courriels des clients restent dans Supabase, accessibles uniquement depuis les fonctions serveur protégées.

Ajouter ou vérifier la politique de confidentialité du site (finalité, durée de conservation, droits RGPD, prestataires). Configurer une sauvegarde régulière et la suppression des données obsolètes avant la mise en service publique.

## Vérifications avant ouverture

- [ ] Version de page d'accueil à jour
- [ ] DATABASE_URL opérationnel et SQL exécuté
- [ ] ADMIN_TOKEN secret configuré
- [ ] Adresse privée de départ renseignée
- [ ] E-mails clients et administratrice testés
- [ ] Durées indicatives des prestations validées
- [ ] Essai de réservation, conflit, validation, refus, expiration (4 h), indisponibilité
- [ ] Mentions légales / confidentialité vérifiées

**Ne pas annoncer que les réservations sont opérationnelles avant d'avoir terminé cette liste.**
