'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DateTime } = require('luxon');
const { TZ, durationFor, priceFor, SERVICES, NOTICE_HOURS } = require('../lib/config');

// Stub only external routing in local tests. No external API call or personal data.
const geoPath = require.resolve('../lib/geo');
require.cache[geoPath] = {
  id: geoPath, filename: geoPath, loaded: true,
  exports: {
    route: async (from, to) => (from.lat === to.lat && from.lon === to.lon ? 0 : 20),
    point: obj => ({lat:Number(obj.lat), lon:Number(obj.lon)})
  }
};
const { checkSlot } = require('../lib/slots');
const day = DateTime.now().setZone(TZ).plus({days:15}).toFormat('yyyy-MM-dd');
const iso = time => DateTime.fromISO(`${day}T${time}`,{zone:TZ}).toUTC().toISO();
const origin={lat:45.76,lon:5.93};

function booking(start, end, coords=origin){
  return {type:'booking',status:'confirmed',start_at:iso(start),end_at:iso(end),...coords};
}
function slot(time, minutes=30, bookings=[], loc=origin){
  return checkSlot({day,startISO:iso(time),duration:minutes,loc,bookings,base:origin});
}

test('prestations : durée et quantités préservées',()=>{
 assert.equal(durationFor('visite',{horses:1}),30);
 assert.equal(durationFor('visite',{horses:2}),60);
 assert.equal(durationFor('boxes_paddocks',{horses:1,boxes:2,paddocks:1}),60);
 assert.equal(durationFor('boxes',{horses:1,boxes:0,paddocks:0}),null);
 assert.equal(durationFor('boxes',{horses:1,boxes:100,paddocks:0}),null);
 assert.equal(durationFor('visite',{horses:4}),null);
 assert.ok(Object.keys(SERVICES).length>=15);
});

test('tarif propriétaire : deux chevaux bénéficient de -10%',()=>{
 assert.match(priceFor('visite',2),/41,40/);
 assert.match(priceFor('visite',2),/10\s*%/);
});

test('aucune réservation avant 7h ni après fin de prestation à 20h',async()=>{
 assert.equal((await slot('06:30')).ok,false);
 assert.equal((await slot('19:30',60)).ok,false);
 assert.equal((await slot('19:30',30)).ok,true);
});

test('tampon de 10 min entre deux prestations, même dans la même écurie',async()=>{
 const before=[booking('08:00','08:30')];
 const after=[booking('09:30','10:00')];
 assert.equal((await slot('08:30',30,before)).ok,false);
 assert.equal((await slot('09:00',30,before)).ok,true);
 assert.equal((await slot('09:00',30,after)).ok,false);
 assert.equal((await slot('08:30',30,after)).ok,true);
});

test('le trajet entre deux écuries s’ajoute à la marge',async()=>{
 const other={lat:45.85,lon:6.07};
 assert.equal((await slot('08:30',30,[booking('08:00','08:30')],other)).ok,false);
 assert.equal((await slot('09:00',30,[booking('08:00','08:30')],other)).ok,true);
});

test('aucun créneau qui chevauche une indisponibilité',async()=>{
 const blocked=[{type:'block',status:'blocked',start_at:iso('11:00'),end_at:iso('12:00')}];
 assert.equal((await slot('11:00',30,blocked)).ok,false);
 assert.equal((await slot('10:30',30,blocked)).ok,false);
});

test('préavis configuré pour les réservations',()=>{
 assert.equal(NOTICE_HOURS,12);
});
