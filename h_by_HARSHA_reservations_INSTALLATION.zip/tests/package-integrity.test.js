'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
test('le site existant et les pages rendez-vous sont inclus',()=>{
 for(const f of ['public/index.html','public/reserver/index.html','public/gestion/index.html','public/reserver/merci/index.html','netlify/functions/booking.js','netlify/functions/admin.js','netlify.toml']){
  assert.ok(fs.statSync(path.join(root,f)).size>100,f);
 }
});
test('aucun secret ni connexion sensible dans les pages publiques',()=>{
 for(const f of ['public/index.html','public/reserver/index.html','public/gestion/index.html']){
 const html=fs.readFileSync(path.join(root,f),'utf8');
 assert.equal(/(?:sk_test_|sk_live_|sb_secret_|service_role\s*=|DATABASE_URL\s*=|ADMIN_TOKEN\s*=)/.test(html),false,f);
 }
});
