'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {publicCity}=require('../lib/geo');

test('seule la commune est publiable',()=>{
 assert.equal(publicCity('Rumilly'),'Rumilly');
 assert.equal(publicCity('Saint-Félix'),'Saint-Félix');
 assert.equal(publicCity('Moye'),'Moye');
 assert.equal(publicCity('99 impasse de la grande barme'),null);
 assert.equal(publicCity('74150 Rumilly'),null);
});

test('endpoint: rendez-vous confirmés uniquement et sans détails clients',()=>{
 const s=fs.readFileSync(path.join(__dirname,'../netlify/functions/agenda.js'),'utf8');
 assert.match(s,/status='confirmed'/);
 assert.match(s,/public_city/);
 assert.match(s,/SELECT start_at,public_city/);
 assert.doesNotMatch(s,/SELECT \*/);
});

test('agenda: déplacements affichés sans bouton dédié',()=>{
 const s=fs.readFileSync(path.join(__dirname,'../public/reserver/index.html'),'utf8');
 assert.match(s,/visit-location/);
 assert.match(s,/confirmedVisits\(date\)/);
 assert.doesNotMatch(s,/Demander un rendez-vous à proximité/);
});
