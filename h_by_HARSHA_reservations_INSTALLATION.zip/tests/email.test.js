'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {sendMail}=require('../lib/email');
test('notifications : aucune fausse confirmation et deux destinataires distincts',async()=>{
 const original=global.fetch;
 const keys=['BREVO_API_KEY','RESEND_API_KEY','MAIL_FROM','MAIL_TO'];
 const previous=Object.fromEntries(keys.map(k=>[k,process.env[k]]));
 try{
  keys.forEach(k=>delete process.env[k]);
  assert.equal((await sendMail('client@example.invalid','Demande','Texte')).sent,false);
  Object.assign(process.env,{BREVO_API_KEY:'test-only',MAIL_FROM:'contact@example.invalid',MAIL_TO:'owner@example.invalid'});
  const recipients=[];
  global.fetch=async(url,opts)=>{assert.equal(url,'https://api.brevo.com/v3/smtp/email');recipients.push(JSON.parse(opts.body).to[0].email);return {ok:true,json:async()=>({messageId:'test-id'})}};
  assert.equal((await sendMail(process.env.MAIL_TO,'Nouvelle demande','Texte')).sent,true);
  assert.equal((await sendMail('client@example.invalid','Votre demande','Texte')).sent,true);
  assert.deepEqual(recipients,['owner@example.invalid','client@example.invalid']);
  global.fetch=async()=>({ok:false,status:403});
  assert.equal((await sendMail('client@example.invalid','Demande','Texte')).sent,false);
  global.fetch=async()=>{throw new Error('network')};
  assert.equal((await sendMail('client@example.invalid','Demande','Texte')).sent,false);
 }finally{global.fetch=original;keys.forEach(k=>{if(previous[k]===undefined)delete process.env[k];else process.env[k]=previous[k]})}
});
